"""журнал событий: пишем строки в текстовый файл с датой и временем."""
from datetime import datetime

LOG_FILE = "network_log.txt"


def log(text):
    """дописывает строку в журнал."""
    with open(LOG_FILE, "a", encoding="utf-8") as file:
        file.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {text}\n")
