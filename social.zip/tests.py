"""тесты. запуск:  python tests.py"""
import os
import logger
from errors import (ValidationError, UserNotFoundError, BlockedError,
                    SpamError, InvalidCommandError, ProjectError, SaveError)
from network import Network
from post import Post, TextPost, PhotoPost
from console import Console

logger.LOG_FILE = "test_log.txt"   # тесты пишут в свой журнал


def raises(error_type, func, *args):
    """True, если функция бросила нужную ошибку."""
    try:
        func(*args)
    except error_type:
        return True
    return False


def make_net():
    """Сеть с тремя пользователями."""
    net = Network()
    for name in ("Аня", "Боря", "Вика"):
        net.register(name)
    return net


def test_register_and_duplicate():
    net = make_net()
    assert len(net) == 3 and "Аня" in net
    assert raises(ValidationError, net.register, "Аня")      # имя занято
    assert raises(ValidationError, net.register, "А")        # слишком короткое


def test_follow():
    net = make_net()
    net.follow("Аня", "Боря")
    assert "Боря" in net.get_user("Аня").following
    assert raises(ValidationError, net.follow, "Аня", "Боря")  # уже подписана
    assert raises(ValidationError, net.follow, "Аня", "Аня")   # на себя нельзя


def test_unknown_user():
    net = make_net()
    assert raises(UserNotFoundError, net.follow, "Аня", "Призрак")


def test_block():
    net = make_net()
    net.follow("Аня", "Боря")
    net.block("Боря", "Аня")
    assert "Боря" not in net.get_user("Аня").following        # отписка сработала
    assert raises(BlockedError, net.follow, "Аня", "Боря")


def test_like_once():
    net = make_net()
    post = net.post_text("Боря", "Привет")
    net.like("Аня", post.id)
    net.like("Аня", post.id)
    assert post.likes_count == 1                              # второй лайк не считается


def test_empty_post():
    net = make_net()
    assert raises(ValidationError, net.post_text, "Аня", "   ")


def test_spam():
    net = make_net()
    for i in range(3):
        net.post_text("Аня", f"пост {i}")
    assert raises(SpamError, net.post_text, "Аня", "четвёртый")


def test_spam_reset_by_ticks():
    net = make_net()
    for i in range(3):
        net.post_text("Аня", f"пост {i}")
    for _ in range(5):
        net.next_tick()
    net.post_text("Аня", "снова можно")                       # окно сбросилось


def test_feed_time_and_popular():
    net = make_net()
    net.follow("Аня", "Боря")
    net.follow("Аня", "Вика")
    first = net.post_text("Боря", "первый")
    net.next_tick()
    second = net.post_text("Вика", "второй")
    assert net.feed("Аня", "time") == [second, first]         # новые сверху
    net.like("Аня", first.id)
    assert net.feed("Аня", "popular") == [first, second]      # популярные сверху
    assert raises(InvalidCommandError, net.feed, "Аня", "xyz")


def test_feed_hides_strangers():
    net = make_net()
    net.post_text("Боря", "секрет")
    assert net.feed("Аня") == []                              # Аня не подписана


def test_recommend():
    net = make_net()
    net.follow("Аня", "Боря")
    net.follow("Боря", "Вика")
    assert net.recommend("Аня") == [("Вика", 1)]


def test_chat_and_block():
    net = make_net()
    net.send_message("Аня", "Боря", "Привет")
    chat = net.get_chat("Боря", "Аня")
    assert len(chat) == 1 and list(chat) == [("Аня", "Привет")]
    net.block("Боря", "Аня")
    assert raises(BlockedError, net.send_message, "Аня", "Боря", "Эй")


def test_polymorphism_and_abstract():
    text = TextPost(1, "Аня", 0, "привет")
    photo = PhotoPost(2, "Аня", 0, "cat.jpg", "кот")
    assert text.describe() != photo.describe()
    assert isinstance(photo, TextPost) and isinstance(photo, Post)
    assert raises(TypeError, Post, 1, "Аня", 0)               # абстрактный класс
    assert raises(ValidationError, PhotoPost, 3, "Аня", 0, "a.txt", "текст")


def test_trend_event():
    net = make_net()
    post = net.post_text("Боря", "огонь")
    net.like("Аня", post.id)
    events = []
    for _ in range(5):
        events += net.next_tick()
    assert len(events) == 1 and "трендах" in events[0]


def test_save_and_load():
    net = make_net()
    net.follow("Аня", "Боря")
    net.post_text("Боря", "Привет")
    net.post_photo("Вика", "cat.png", "Кот")
    net.comment("Аня", 1, "Круто")
    net.send_message("Аня", "Вика", "Здорово")
    net.save("test_network.json")
    loaded = Network.load("test_network.json")
    os.remove("test_network.json")
    assert loaded.to_dict() == net.to_dict()
    assert raises(SaveError, Network.load, "нет_такого_файла.json")


def test_console_errors_do_not_crash():
    console = Console(autoload=False)
    assert "Неизвестная команда" in console.execute("dance")
    assert "login" in console.execute("post привет")          # не вошли
    console.execute("register Аня")
    console.execute("login Аня")
    assert "числом" in console.execute("like abc")
    assert "Нужно так" in console.execute("follow")


def test_error_hierarchy():
    assert issubclass(SpamError, ProjectError)
    assert issubclass(BlockedError, ProjectError)


if __name__ == "__main__":
    tests = [value for key, value in sorted(globals().items())
             if key.startswith("test_")]
    for test in tests:
        test()
        print(f"{test.__name__}")
    print(f"\nВсе тесты пройдены: {len(tests)}")
    if os.path.exists("test_log.txt"):
        os.remove("test_log.txt")
