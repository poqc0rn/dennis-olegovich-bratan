"""уведомление: «Вася подписался на вас»."""


class Notification:
    """одно уведомление. бывает прочитанным и непрочитанным."""

    def __init__(self, text, time, read=False):
        self._text = text
        self._time = time
        self._read = read

    @property
    def text(self):
        return self._text

    @property
    def read(self):
        return self._read

    def mark_read(self):
        """Помечаем как прочитанное."""
        self._read = True

    def __str__(self):
        return f"[такт {self._time}] {self._text}"

    def to_dict(self):
        return {"text": self._text, "time": self._time, "read": self._read}

    @classmethod
    def from_dict(cls, data):
        return cls(data["text"], data["time"], data["read"])
