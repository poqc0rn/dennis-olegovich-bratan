"""главный класс — сама соцсеть. он создаёт и хранит всё остальное."""
import json
from errors import (ValidationError, UserNotFoundError, BlockedError,
                    InvalidCommandError, SaveError, ProjectError)
from user import User
from post import TextPost, PhotoPost, post_from_dict
from chat import Chat
from feed import Feed
from logger import log


class Network:
    TREND_EVERY = 5   # раз в сколько тактов случается событие «тренд»

    def __init__(self):
        self._users = {}          # имя -> User
        self._posts = []
        self._chats = {}          # ключ -> Chat
        self._feed = Feed()       # сеть сама создаёт ленту
        self._tick = 0
        self._next_post_id = 1

    # ---------- магия ----------
    def __len__(self):
        return len(self._users)

    def __contains__(self, name):
        return name in self._users

    def __str__(self):
        return (f"Соцсеть: людей {len(self)}, постов {len(self._posts)}, "
                f"такт {self._tick}")

    @property
    def user_names(self):
        return sorted(self._users)

    @property
    def tick_number(self):
        return self._tick

    # ---------- пользователи ----------
    def get_user(self, name):
        if name not in self._users:
            raise UserNotFoundError(f"Пользователь '{name}' не найден")
        return self._users[name]

    def register(self, name):
        if name in self._users:
            raise ValidationError(f"Имя '{name}' уже занято")
        user = User(name)
        self._users[name] = user
        log(f"Регистрация: {name}")
        return user

    def _check_not_blocked(self, name_a, name_b):
        """Проверяем, что никто из двоих не заблокировал другого."""
        user_a = self.get_user(name_a)
        user_b = self.get_user(name_b)
        if user_a.is_blocked(name_b) or user_b.is_blocked(name_a):
            raise BlockedError("Между вами блокировка")

    # ---------- подписки ----------
    def follow(self, me, other):
        if me == other:
            raise ValidationError("Нельзя подписаться на себя")
        self._check_not_blocked(me, other)
        if other in self.get_user(me).following:
            raise ValidationError(f"Вы уже подписаны на {other}")
        self.get_user(me).follow(other)
        self.get_user(other).notify(f"{me} теперь читает вас", self._tick)
        log(f"{me} подписался на {other}")

    def unfollow(self, me, other):
        user = self.get_user(me)
        self.get_user(other)
        if other not in user.following:
            raise ValidationError(f"Вы не подписаны на {other}")
        user.unfollow(other)
        log(f"{me} отписался от {other}")

    def block(self, me, other):
        if me == other:
            raise ValidationError("Нельзя заблокировать себя")
        user = self.get_user(me)
        victim = self.get_user(other)
        user.block(other)
        victim.unfollow(me)       # заблокированный тоже отписывается
        log(f"{me} заблокировал {other}")

    # ---------- посты ----------
    def post_text(self, author, text):
        post = TextPost(self._next_post_id, author, self._tick, text)
        return self._publish(post)

    def post_photo(self, author, photo, text):
        post = PhotoPost(self._next_post_id, author, self._tick, photo, text)
        return self._publish(post)

    def _publish(self, post):
        """Общая часть публикации для любого вида поста."""
        self.get_user(post.author).register_post()   # может бросить SpamError
        self._posts.append(post)
        self._next_post_id += 1
        for user in self._users.values():
            if post.author in user.following:
                user.notify(f"{post.author} опубликовал пост #{post.id}", self._tick)
        log(f"Пост #{post.id} от {post.author}")
        return post

    def _find_post(self, post_id):
        for post in self._posts:
            if post.id == post_id:
                return post
        raise ValidationError(f"Поста #{post_id} нет")

    def like(self, username, post_id):
        self.get_user(username)
        post = self._find_post(post_id)
        if post.author != username:
            self._check_not_blocked(username, post.author)
        before = post.likes_count
        post.like(username)
        if post.likes_count > before and post.author != username:
            self.get_user(post.author).notify(
                f"{username} лайкнул ваш пост #{post_id}", self._tick)
        log(f"{username} лайкнул пост #{post_id}")
        return post

    def comment(self, username, post_id, text):
        self.get_user(username)
        post = self._find_post(post_id)
        if post.author != username:
            self._check_not_blocked(username, post.author)
        post.add_comment(username, text)
        if post.author != username:
            self.get_user(post.author).notify(
                f"{username} комментирует ваш пост #{post_id}", self._tick)
        log(f"{username} прокомментировал пост #{post_id}")
        return post

    # ---------- лента и рекомендации ----------
    def feed(self, name, mode="time"):
        user = self.get_user(name)
        return self._feed.build(user, self._posts, mode)

    def recommend(self, name):
        """рекомендуем «друзей друзей».

        смотрим, на кого подписаны мои подписки. чем больше моих подписок
        подписано на человека — тем он выше в списке.
        Возвращает список пар (имя, сколько_общих).
        """
        me = self.get_user(name)
        counts = {}
        for friend_name in me.following:
            friend = self.get_user(friend_name)
            for candidate in friend.following:
                if candidate == name or candidate in me.following:
                    continue
                if me.is_blocked(candidate):
                    continue
                if self.get_user(candidate).is_blocked(name):
                    continue
                counts[candidate] = counts.get(candidate, 0) + 1
        return sorted(counts.items(), key=lambda pair: (-pair[1], pair[0]))

    # ---------- личные сообщения ----------
    def send_message(self, sender, receiver, text):
        if sender == receiver:
            raise ValidationError("Нельзя писать самому себе")
        self._check_not_blocked(sender, receiver)
        key = Chat.make_key(sender, receiver)
        chat = self._chats.get(key)
        if chat is None:
            chat = Chat(sender, receiver)
        chat.send(sender, text, self._tick)
        self._chats[key] = chat
        self.get_user(receiver).notify(f"Новое сообщение от {sender}", self._tick)
        log(f"Сообщение {sender} → {receiver}")

    def get_chat(self, name_a, name_b):
        self.get_user(name_a)
        self.get_user(name_b)
        return self._chats.get(Chat.make_key(name_a, name_b))

    # ---------- «мир живёт по тактам» ----------
    def next_tick(self):
        """один такт времени. Иногда запускает события. Возвращает их тексты."""
        self._tick += 1
        events = []
        if self._tick % self.TREND_EVERY == 0:
            for user in self._users.values():
                user.reset_window()          # счётчик спама обнуляется
            trend = self._trend_event()
            if trend:
                events.append(trend)
        for event in events:
            log(f"СОБЫТИЕ: {event}")
        return events

    def _trend_event(self):
        """самый популярный пост попадает в тренды."""
        if not self._posts:
            return None
        best = max(self._posts)              # работает через Post.__lt__
        if best.popularity == 0:
            return None
        self.get_user(best.author).notify(
            f"Ваш пост #{best.id} в трендах!", self._tick)
        return f"Пост #{best.id} от {best.author} в трендах!"

    # ---------- JSON ----------
    def to_dict(self):
        return {
            "tick": self._tick,
            "next_post_id": self._next_post_id,
            "users": [u.to_dict() for u in self._users.values()],
            "posts": [p.to_dict() for p in self._posts],
            "chats": [c.to_dict() for c in self._chats.values()],
        }

    @classmethod
    def from_dict(cls, data):
        network = cls()
        network._tick = data["tick"]
        network._next_post_id = data["next_post_id"]
        for user_data in data["users"]:
            user = User.from_dict(user_data)
            network._users[user.name] = user
        network._posts = [post_from_dict(p) for p in data["posts"]]
        for chat_data in data["chats"]:
            chat = Chat.from_dict(chat_data)
            network._chats[chat.key] = chat
        return network

    def save(self, path):
        try:
            with open(path, "w", encoding="utf-8") as file:
                json.dump(self.to_dict(), file, ensure_ascii=False, indent=2)
        except OSError as error:
            raise SaveError(f"Не удалось сохранить: {error}")
        log(f"Сохранено в {path}")

    @classmethod
    def load(cls, path):
        try:
            with open(path, encoding="utf-8") as file:
                data = json.load(file)
            network = cls.from_dict(data)
        except FileNotFoundError:
            raise SaveError("Файл сохранения не найден")
        except (json.JSONDecodeError, KeyError):
            raise SaveError("Файл сохранения повреждён")
        log(f"Загружено из {path}")
        return network
