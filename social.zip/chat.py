"""личная переписка двух пользователей."""
from errors import ProjectError, ValidationError


class Chat:
    """чат между двумя людьми. хранит список сообщений."""

    def __init__(self, user_a, user_b):
        self._users = tuple(sorted([user_a, user_b]))
        self._messages = []

    @staticmethod
    def make_key(user_a, user_b):
        """ключ чата не зависит от порядка имён: Аня|Боря = Боря|Аня."""
        return "|".join(sorted([user_a, user_b]))

    @property
    def key(self):
        return "|".join(self._users)

    def send(self, author, text, time):
        if author not in self._users:
            raise ProjectError("Вы не участник этого чата")
        if not text or not text.strip():
            raise ValidationError("Сообщение не может быть пустым")
        self._messages.append({"from": author, "text": text.strip(), "time": time})

    def __len__(self):
        return len(self._messages)

    def __iter__(self):
        for message in self._messages:
            yield message["from"], message["text"]

    def __str__(self):
        return f"Чат {self._users[0]} ↔ {self._users[1]} ({len(self)} сообщ.)"

    def to_dict(self):
        return {"users": list(self._users), "messages": self._messages}

    @classmethod
    def from_dict(cls, data):
        chat = cls(data["users"][0], data["users"][1])
        chat._messages = data["messages"]
        return chat
