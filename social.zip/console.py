"""консоль: читает команды пользователя и вызывает методы сети."""
import os
from errors import ProjectError, InvalidCommandError
from network import Network
from logger import log

SAVE_FILE = "network.json"

# команды для автоматического показа (команда demo)
DEMO_SCRIPT = [
    "register Аня", "register Боря", "register Вика", "register Гоша",
    "login Боря", "follow Вика", "post дарова ребятки, я Боря!",
    "login Гоша", "follow Вика",
    "login Вика", "post Вика на связи", "photo kot.jpg Мой кот",
    "login Аня", "follow Боря", "follow Гоша",
    "recommend",
    "follow Вика",
    "feed",
    "like 3", "comment 3 Какой милый котик!))",
    "login Гоша", "msg Боря салам Боря",
    "login Боря", "chat Гоша",
    "login Вика", "notes", "block Аня",
    "login Аня", "follow Вика", "msg Вика Привет",
    "feed popular",
    "dance",
    "post",
]


class Console:
    # эти команды не двигают время вперёд
    NO_TICK = {"help", "save", "load", "exit", "demo", "login", "users"}

    def __init__(self, autoload=True):
        self.network = Network()
        self.current = None       # кто сейчас «вошёл»
        self.running = True

        # словарь команд: слово -> метод. help берёт тексты из docstring.
        self.commands = {
            "help": self.cmd_help,
            "register": self.cmd_register,
            "login": self.cmd_login,
            "users": self.cmd_users,
            "post": self.cmd_post,
            "photo": self.cmd_photo,
            "follow": self.cmd_follow,
            "unfollow": self.cmd_unfollow,
            "block": self.cmd_block,
            "like": self.cmd_like,
            "comment": self.cmd_comment,
            "feed": self.cmd_feed,
            "recommend": self.cmd_recommend,
            "notes": self.cmd_notes,
            "msg": self.cmd_msg,
            "chat": self.cmd_chat,
            "save": self.cmd_save,
            "load": self.cmd_load,
            "demo": self.cmd_demo,
            "exit": self.cmd_exit,
        }

        if autoload and os.path.exists(SAVE_FILE):
            try:
                self.network = Network.load(SAVE_FILE)
                print("Прошлое сохранение загружено автоматически")
            except ProjectError as error:
                print(f"{error}")

    # ---------- главный метод ----------
    def execute(self, line):
        """Выполняет одну строку-команду и возвращает текст ответа."""
        parts = line.split()
        if not parts:
            return ""
        name, args = parts[0].lower(), parts[1:]
        try:
            if name not in self.commands:
                raise InvalidCommandError(f"Неизвестная команда '{name}'. Напишите help")
            result = self.commands[name](args)
            log(f"Команда: {line}")
            if name not in self.NO_TICK:
                for event in self.network.next_tick():
                    result += f"\n{event}"
            return result
        except ProjectError as error:
            log(f"Ошибка: {error} (команда: {line})")
            return f"{error}"
        except Exception as error:      # на всякий случай: программа не падает
            log(f"Неожиданная ошибка: {error}")
            return f"Неожиданная ошибка: {error}"

    def run(self):
        print("Соцсеть. Напишите help, чтобы увидеть команды.")
        while self.running:
            try:
                line = input(f"[{self.current or '-'}]> ")
            except (EOFError, KeyboardInterrupt):
                print()
                break
            answer = self.execute(line)
            if answer:
                print(answer)

    # ---------- маленькие помощники ----------
    def _need_user(self):
        if self.current is None:
            raise InvalidCommandError("Сначала войдите: login <имя>")
        return self.current

    @staticmethod
    def _need_args(args, count, usage):
        if len(args) < count:
            raise InvalidCommandError(f"Нужно так: {usage}")

    @staticmethod
    def _to_id(text):
        try:
            return int(text)
        except ValueError:
            raise InvalidCommandError("Номер поста должен быть числом")

    # ---------- команды (docstring = текст справки) ----------
    def cmd_help(self, args):
        """help — показать все команды"""
        lines = ["Команды:"]
        for func in self.commands.values():
            lines.append("  " + func.__doc__)
        return "\n".join(lines)

    def cmd_register(self, args):
        """register <имя> — создать пользователя"""
        self._need_args(args, 1, "register <имя>")
        self.network.register(args[0])
        return f"Пользователь {args[0]} создан"

    def cmd_login(self, args):
        """login <имя> — войти как пользователь"""
        self._need_args(args, 1, "login <имя>")
        self.network.get_user(args[0])
        self.current = args[0]
        return f"Вы вошли как {args[0]}"

    def cmd_users(self, args):
        """users — список всех пользователей"""
        return "Пользователи: " + (", ".join(self.network.user_names) or "пока никого")

    def cmd_post(self, args):
        """post <текст> — написать текстовый пост"""
        post = self.network.post_text(self._need_user(), " ".join(args))
        return f"Опубликовано: {post}"

    def cmd_photo(self, args):
        """photo <файл.jpg> <текст> — пост с фото"""
        self._need_args(args, 2, "photo <файл.jpg> <текст>")
        post = self.network.post_photo(self._need_user(), args[0], " ".join(args[1:]))
        return f"Опубликовано: {post}"

    def cmd_follow(self, args):
        """follow <имя> — подписаться"""
        self._need_args(args, 1, "follow <имя>")
        self.network.follow(self._need_user(), args[0])
        return f"Вы подписались на {args[0]}"

    def cmd_unfollow(self, args):
        """unfollow <имя> — отписаться"""
        self._need_args(args, 1, "unfollow <имя>")
        self.network.unfollow(self._need_user(), args[0])
        return f"Вы отписались от {args[0]}"

    def cmd_block(self, args):
        """block <имя> — заблокировать"""
        self._need_args(args, 1, "block <имя>")
        self.network.block(self._need_user(), args[0])
        return f"{args[0]} заблокирован"

    def cmd_like(self, args):
        """like <номер поста> — поставить лайк"""
        self._need_args(args, 1, "like <номер поста>")
        post = self.network.like(self._need_user(), self._to_id(args[0]))
        return f"Лайк! Теперь у поста #{post.id} лайков: {post.likes_count}"

    def cmd_comment(self, args):
        """comment <номер поста> <текст> — комментарий"""
        self._need_args(args, 2, "comment <номер поста> <текст>")
        post_id = self._to_id(args[0])
        self.network.comment(self._need_user(), post_id, " ".join(args[1:]))
        return f"Комментарий добавлен к посту #{post_id}"

    def cmd_feed(self, args):
        """feed [time|popular] — моя лента (по времени или по популярности)"""
        mode = args[0] if args else "time"
        posts = self.network.feed(self._need_user(), mode)
        if not posts:
            return "Лента пуста. Подпишитесь на кого-нибудь или напишите пост."
        lines = [f"Лента ({mode}):"]
        for post in posts:                       # разные посты, один вызов describe()
            lines.append(f"  #{post.id} [{post.author}] {post.describe()}"
                         f"  ❤  {post.likes_count} 💬 {post.comments_count}")
            for comment in post.comments:
                lines.append(f"         {comment}")
        return "\n".join(lines)

    def cmd_recommend(self, args):
        """recommend — кого мне стоит читать"""
        result = self.network.recommend(self._need_user())
        if not result:
            return "Пока нет рекомендаций. Подпишитесь на кого-нибудь."
        lines = ["Возможно, вы знаете:"]
        for name, count in result:
            lines.append(f"  {name} (на него подписаны ваши подписки: {count})")
        return "\n".join(lines)

    def cmd_notes(self, args):
        """notes — новые уведомления"""
        user = self.network.get_user(self._need_user())
        fresh = user.take_unread()
        if not fresh:
            return "Новых уведомлений нет"
        return "\n".join(str(note) for note in fresh)

    def cmd_msg(self, args):
        """msg <имя> <текст> — личное сообщение"""
        self._need_args(args, 2, "msg <имя> <текст>")
        self.network.send_message(self._need_user(), args[0], " ".join(args[1:]))
        return f"Отправлено пользователю {args[0]}"

    def cmd_chat(self, args):
        """chat <имя> — переписка с человеком"""
        self._need_args(args, 1, "chat <имя>")
        chat = self.network.get_chat(self._need_user(), args[0])
        if chat is None:
            return "Сообщений пока нет"
        lines = [str(chat)]
        for author, text in chat:
            lines.append(f"  {author}: {text}")
        return "\n".join(lines)

    def cmd_save(self, args):
        """save — сохранить в JSON"""
        self.network.save(SAVE_FILE)
        return f"Сохранено в {SAVE_FILE}"

    def cmd_load(self, args):
        """load — загрузить из JSON"""
        self.network = Network.load(SAVE_FILE)
        if self.current not in self.network:
            self.current = None
        return "Загружено"

    def cmd_demo(self, args):
        """demo — автоматический показ работы (на чистой сети)"""
        self.network = Network()
        self.current = None
        for line in DEMO_SCRIPT:
            print(f"> {line}")
            answer = self.execute(line)
            if answer:
                print(answer)
        return " Демо закончено"

    def cmd_exit(self, args):
        """exit — выйти"""
        self.running = False
        return "Пока!"
