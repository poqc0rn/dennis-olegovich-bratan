"""лента: решает, какие посты показать человеку и в каком порядке."""
from errors import InvalidCommandError


class Feed:
    MODES = ("time", "popular")

    def build(self, user, posts, mode="time"):
        """возвращает список постов для user.

        time    — сначала новые
        popular — сначала самые популярные
        """
        if mode not in self.MODES:
            raise InvalidCommandError("Режим ленты: time или popular")

        visible = [post for post in posts if self._can_see(user, post)]

        if mode == "popular":
            visible.sort(reverse=True)     # работает через Post.__lt__
        else:
            visible.sort(key=lambda post: post.time, reverse=True)
        return visible

    @staticmethod
    def _can_see(user, post):
        """видим свои посты и посты тех, на кого подписаны."""
        if post.author == user.name:
            return True
        return post.author in user.following and not user.is_blocked(post.author)

    def __str__(self):
        return "Лента (режимы: time, popular)"
