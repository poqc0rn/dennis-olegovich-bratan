"""все наши ошибки. у всех один папа — ProjectError."""


class ProjectError(Exception):
    """общая ошибка проекта."""


class ValidationError(ProjectError):
    """плохие данные: пустой текст, занятое имя и т.п."""


class UserNotFoundError(ProjectError):
    """такого пользователя нет."""


class BlockedError(ProjectError):
    """между пользователями стоит блокировка."""


class SpamError(ProjectError):
    """слишком много постов подряд."""


class InvalidCommandError(ProjectError):
    """неизвестная команда или неверные аргументы."""


class SaveError(ProjectError):
    """проблема с файлом сохранения."""