"""посты и комментарии.

лесенка наследования:  Post (абстрактный) → TextPost → PhotoPost
"""
from abc import ABC, abstractmethod
from errors import ValidationError


class Comment:
    """комментарий под постом."""

    def __init__(self, author, text):
        self._author = author
        self._text = text

    @property
    def author(self):
        return self._author

    @property
    def text(self):
        return self._text

    def __str__(self):
        return f"{self._author}: {self._text}"

    def to_dict(self):
        return {"author": self._author, "text": self._text}

    @classmethod
    def from_dict(cls, data):
        return cls(data["author"], data["text"])


class Post(ABC):
    """абстрактный пост. Сам по себе не существует — только TextPost и т.д."""

    MAX_LEN = 200

    def __init__(self, post_id, author, time):
        self._id = post_id
        self._author = author
        self._time = time
        self._likes = set()      # множество имён: один человек = один лайк
        self._comments = []

    # --- только чтение (защищённое состояние) ---
    @property
    def id(self):
        return self._id

    @property
    def author(self):
        return self._author

    @property
    def time(self):
        return self._time

    @property
    def likes_count(self):
        return len(self._likes)

    @property
    def comments_count(self):
        return len(self._comments)

    @property
    def comments(self):
        return list(self._comments)

    @property
    def popularity(self):
        """популярность: лайк = 1 очко, комментарий = 2 очка."""
        return self.likes_count + 2 * self.comments_count

    # --- действия ---
    def like(self, username):
        self._likes.add(username)

    def add_comment(self, author, text):
        self.check_text(text)
        self._comments.append(Comment(author, text.strip()))

    @staticmethod
    def check_text(text):
        """проверка текста: не пустой и не слишком длинный."""
        if not text or not text.strip():
            raise ValidationError("Текст не может быть пустым")
        if len(text) > Post.MAX_LEN:
            raise ValidationError(f"Слишком длинно (максимум {Post.MAX_LEN})")

    # --- то, что каждый наследник обязан сделать сам ---
    @abstractmethod
    def describe(self):
        """как пост выглядит в ленте."""

    @abstractmethod
    def to_dict(self):
        """пост → словарь для JSON."""

    # --- помощники для JSON ---
    def _base_dict(self, kind):
        return {
            "type": kind,
            "id": self._id,
            "author": self._author,
            "time": self._time,
            "likes": sorted(self._likes),
            "comments": [c.to_dict() for c in self._comments],
        }

    def _load_extra(self, data):
        """Достаём лайки и комментарии после загрузки."""
        self._likes = set(data["likes"])
        self._comments = [Comment.from_dict(c) for c in data["comments"]]

    # --- магия ---
    def __str__(self):
        return (f"#{self._id} от {self._author}: {self.describe()} "
                f"(❤ {self.likes_count}, 💬 {self.comments_count})")

    def __eq__(self, other):
        return isinstance(other, Post) and self._id == other._id

    def __hash__(self):
        return hash(self._id)

    def __lt__(self, other):
        """Пост «меньше», если менее популярен (нужно для sorted и max)."""
        return self.popularity < other.popularity


class TextPost(Post):
    """Обычный текстовый пост."""

    def __init__(self, post_id, author, time, text):
        self.check_text(text)
        super().__init__(post_id, author, time)
        self._text = text.strip()

    @property
    def text(self):
        return self._text

    def describe(self):
        return f"{self._text}"

    def to_dict(self):
        data = self._base_dict("text")
        data["text"] = self._text
        return data

    @classmethod
    def from_dict(cls, data):
        post = cls(data["id"], data["author"], data["time"], data["text"])
        post._load_extra(data)
        return post


class PhotoPost(TextPost):
    """пост с фото = текстовый пост + имя файла картинки."""

    def __init__(self, post_id, author, time, photo, text):
        self.check_photo(photo)
        super().__init__(post_id, author, time, text)
        self._photo = photo

    @staticmethod
    def check_photo(photo):
        """фото должно быть .jpg / .jpeg / .png."""
        if not photo.lower().endswith((".jpg", ".jpeg", ".png")):
            raise ValidationError("Фото должно быть .jpg, .jpeg или .png")

    @property
    def photo(self):
        return self._photo

    def describe(self):
        return f"[{self._photo}] {self._text}"

    def to_dict(self):
        data = super().to_dict()
        data["type"] = "photo"
        data["photo"] = self._photo
        return data

    @classmethod
    def from_dict(cls, data):
        post = cls(data["id"], data["author"], data["time"],
                   data["photo"], data["text"])
        post._load_extra(data)
        return post


def post_from_dict(data):
    """смотрит на поле type и собирает нужный вид поста."""
    if data["type"] == "photo":
        return PhotoPost.from_dict(data)
    return TextPost.from_dict(data)
