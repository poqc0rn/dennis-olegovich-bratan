"""точка входа. Только запускает консоль."""
from console import Console

if __name__ == "__main__":
    Console().run()
