"""пользователь соцсети."""
from errors import ValidationError, SpamError
from notification import Notification


class User:
    """хранит: на кого подписан, кого заблокировал, уведомления."""

    MAX_POSTS = 3   # сколько постов можно написать за одно «окно» тактов

    def __init__(self, name):
        self.check_name(name)
        self._name = name
        self._following = set()
        self._blocked = set()
        self._notifications = []
        self._recent_posts = 0

    @staticmethod
    def check_name(name):
        """имя: от 2 до 20 символов."""
        if not name or len(name) < 2 or len(name) > 20:
            raise ValidationError("Имя должно быть от 2 до 20 символов")

    @property
    def name(self):
        return self._name

    @property
    def following(self):
        return set(self._following)   # копия, чтобы снаружи не сломали

    @property
    def blocked(self):
        return set(self._blocked)

    @property
    def notifications(self):
        return list(self._notifications)

    # --- подписки и блокировки ---
    def follow(self, name):
        self._following.add(name)

    def unfollow(self, name):
        self._following.discard(name)

    def block(self, name):
        """блокируем человека и сразу отписываемся от него."""
        self._blocked.add(name)
        self._following.discard(name)

    def is_blocked(self, name):
        return name in self._blocked

    # --- уведомления ---
    def notify(self, text, time):
        self._notifications.append(Notification(text, time))

    def take_unread(self):
        """возвращает непрочитанные и сразу помечает прочитанными."""
        fresh = [n for n in self._notifications if not n.read]
        for note in fresh:
            note.mark_read()
        return fresh

    # --- защита от спама ---
    def register_post(self):
        """считаем пост. Если их слишком много — ругаемся."""
        if self._recent_posts >= self.MAX_POSTS:
            raise SpamError("Спам! Подождите несколько тактов перед новым постом")
        self._recent_posts += 1

    def reset_window(self):
        self._recent_posts = 0

    # --- магия ---
    def __str__(self):
        return f"{self._name} (подписок: {len(self._following)})"

    def __eq__(self, other):
        return isinstance(other, User) and self._name == other._name

    def __hash__(self):
        return hash(self._name)

    # --- JSON ---
    def to_dict(self):
        return {
            "name": self._name,
            "following": sorted(self._following),
            "blocked": sorted(self._blocked),
            "notifications": [n.to_dict() for n in self._notifications],
            "recent_posts": self._recent_posts,
        }

    @classmethod
    def from_dict(cls, data):
        user = cls(data["name"])
        user._following = set(data["following"])
        user._blocked = set(data["blocked"])
        user._notifications = [Notification.from_dict(n)
                               for n in data["notifications"]]
        user._recent_posts = data["recent_posts"]
        return user
